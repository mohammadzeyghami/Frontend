export const HomePage = () => {
  return <h2>Home Page</h2>
}
