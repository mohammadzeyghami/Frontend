export const RQSuperHeroesPage = () => {
  return <h2>React Query Super Heroes Page</h2>
}
